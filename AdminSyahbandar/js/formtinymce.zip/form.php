<html>
	<title>Tutorial Menambah TinyMCE kedalam PHP</title>
<head>
<script type="text/javascript" src="tinymce/jscripts/tiny_mce/tiny_mce.js"></script>
<script type="text/javascript">
tinyMCE.init({
        	// General options
        	mode : "textareas",
        	theme : "advanced",
});
</script>
</head>
<body>
<table>
<tr>
	<td>Judul</td>
	<td>:</td>
	<td><input type="text" name="judul"></td>
</tr>
<tr>
	<td>subjudul</td>
	<td>:</td>
	<td><input type="text" name="subjudul"></td>
</tr>
<tr>
	<td>Artikel</td>
	<td>:</td>
	<td><textarea name="artikel"></textarea></td>
</tr>
</table>
</body>
</html>
